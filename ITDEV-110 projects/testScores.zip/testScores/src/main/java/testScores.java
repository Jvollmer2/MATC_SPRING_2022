/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jvoll
 */
import java.util.Scanner;
public class testScores {
    static double getAverage(double x, double y, double z){
        double average = (x + y + z) / 3;
        return average;
    }
    public static void main(String[] args){
        
        Scanner myObj = new Scanner(System.in);
        
        System.out.println("What is the class name?");
        String className = myObj.nextLine();
        System.out.println("What was your score on the first test");
        double scoreA = myObj.nextDouble();
        System.out.println("What was your score on the second test");
        double scoreB = myObj.nextDouble();
        System.out.println("What was your score on the third test");
        double scoreC = myObj.nextDouble();
        
        Class myClass = new Class(className, scoreA, scoreB, scoreC);
        
        double average = getAverage(myClass.testScoreA, myClass.testScoreB, myClass.testScoreC);
        //round to 2 decimals.
        
        System.out.println("The average test score you have in " + myClass.className + " " + average + " %.");
    }
}
