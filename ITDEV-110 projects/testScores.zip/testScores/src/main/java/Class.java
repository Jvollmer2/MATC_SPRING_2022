/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jvoll
 */
public class Class {
    String className;
    double testScoreA;
    double testScoreB;
    double testScoreC;
    
    //Constructor
    public Class(String x, double a, double b, double c){
       className = x;
       testScoreA = a;
       testScoreB = b;
       testScoreC = c;   
   }
}
