/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jvoll
 */
import java.util.Scanner;
public class IsPrime {
    
    static boolean checkIfPrime(int x){
        for(int i=2; i<x; i++){
            if(x%i == 0){
                return false;
            }         
        }     
        return true;
    }
    
    public static void main(String args[]){
        
        int x;
        boolean isPrime = false;
        Scanner myObj = new Scanner(System.in);
        
        System.out.println("Choose any whole number: ");
        x = myObj.nextInt();
        //make sure x is a valid whole number
        
        isPrime = checkIfPrime(x);
        
        if(isPrime){System.out.println(x + " is prime.");}
        else{System.out.println(x + " is not prime.");}
    }

}
