/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jvoll
 */
import java.util.Scanner;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class BMI {
    
    private static final DecimalFormat df = new DecimalFormat("0.00");
    
    public static void main(String args[]){
        
        Scanner myObj = new Scanner(System.in);
        
        double weight;
        double height;

        weight = Double.parseDouble(JOptionPane.showInputDialog(null,"In pounds, what is your weight?"));
        height = Double.parseDouble(JOptionPane.showInputDialog(null,"In inches, how tall are you?"));
        
        double bmi = Double.parseDouble(df.format(weight * (703/Math.pow(height, 2))));
        
        JOptionPane.showMessageDialog(null, "Your  BMI is " + bmi + "%.");        
        
        if (bmi < 18.5){
            JOptionPane.showMessageDialog(null, "You are underweight.");
        }
        else if (bmi > 25){
            JOptionPane.showMessageDialog(null, "You are overweight.");
        }
        else {
            JOptionPane.showMessageDialog(null, "You are at an optimal weight");
        };
    }
}
