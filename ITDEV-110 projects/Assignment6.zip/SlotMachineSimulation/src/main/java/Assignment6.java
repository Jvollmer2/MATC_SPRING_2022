/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jvoll
 */
import java.util.Scanner;
import java.util.Random;
import javax.swing.JOptionPane;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class Assignment6 {
    
    public static void main(String args[]){
        
        Scanner myObj = new Scanner(System.in);
        Random rand = new Random();
//enter money into slot, round to 2 decimals
        double money = Double.parseDouble(JOptionPane.showInputDialog(null,"How much money would you like to put in the slot machine?"));
        money = Math.round(money *  100.0)/100.0;
//bet amount, round to 2 decimals
        double bet = 0;
        String[] fruits = {"Cherries ", "Oranges ", "Plums ", "Bells ", "Melons ", "Bars "};
        String[] slots = {null, null, null};
        double totalWon = 0;
        double totalBet =0;
    
        do{
            do{
                bet = Double.parseDouble(JOptionPane.showInputDialog(null,"You have $" + money + ", How much would you like to bet?"));
                if(bet < 0){
                    JOptionPane.showMessageDialog(null, "You can't bet negative money!");
                }
                if(bet > money){
                    JOptionPane.showMessageDialog(null, "You don't have enough to bet that much!");
                }
            }while(bet > money || bet < 0);
            bet = Math.round(bet * 100.0)/100.0;
            money = money - bet;
            totalBet += bet;
//spin
            for (int i = 0; i < 3; i++){
                int random = rand.nextInt(5);
                slots[i] = fruits[random];
            }
            JOptionPane.showMessageDialog(null, slots[0] + slots[1] + slots[2]);
//if double triple
            if(slots[0]==slots[1]||slots[0]==slots[2]||slots[2]==slots[1]){
                if(slots[0]==slots[1]&&slots[0]==slots[2]){
                    money = Math.round(money + (bet*3));
                    totalWon += (bet*3);
                    JOptionPane.showMessageDialog(null, "You tripled your bet! +$" + (bet*3) + " Current funds: $" + money);
                }
                else{
                    money = Math.round(money + (bet*2));
                    totalWon += (bet*2);
                    JOptionPane.showMessageDialog(null, "You doubled your bet! +$" + (bet*2) + " Current funds: $" + money);
                }
            }   
            else{
                money = Math.round(money * 100.0)/100.0;
                JOptionPane.showMessageDialog(null, "You lost! -$" + bet + " Current funds: $" + money);
            }
        }while(JOptionPane.showConfirmDialog(null, "Would you like to play again?", "Respin", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION); 
        JOptionPane.showMessageDialog(null, "Done Playing, you cashed out: $" + money + ", you bet a total of: $" + totalBet + ", and won a total of: $" + totalWon);
        double profit = totalWon - totalBet;
        JOptionPane.showMessageDialog(null, "You profited: $" + profit);
    }
}
