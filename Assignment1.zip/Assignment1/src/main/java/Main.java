/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jvoll
 */
public class Main {
    
//Name:            Your name

//Instructor:       Mr. Robert Menzl

//Course:          ITDEV-110-200

//Assignment:   1 - Introduction to Java

//Date:               January 25, 2022
    
    public static void main(String[] args){
        
        System.out.println("John Vollmer");
        System.out.println();
        System.out.println("Mr. Robert Menzel");
        System.out.println();
        System.out.println("ITDEV-110-200");
        System.out.println();
        System.out.println("1 - Introduction to Java");
        System.out.println();
        System.out.println("January 18, 2022");
        
    }
    
}
