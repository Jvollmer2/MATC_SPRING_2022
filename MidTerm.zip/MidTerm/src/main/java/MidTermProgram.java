/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jvoll
 */
import java.util.Scanner;
public class MidTermProgram {
    public static void main(String[] args){
        
        Scanner myObj = new Scanner(System.in);
        String words[] = new String[3];
        String temp;
        
        System.out.println("Please enter the first word.");
        words[0] = myObj.nextLine();
        System.out.println("Please enter the second word.");
        words[1] = myObj.nextLine();
        System.out.println("Please enter the third word.");
        words[2] = myObj.nextLine();
        
        for(int i = 0; i < 3; i++){
            for(int j = i + 1; j < 3; j++){
                if(words[i].compareTo(words[j])>0){
                    temp = words[i];
                    words[i] = words[j];
                    words[j] = temp;
                }
            }
        }
        
        for(int i = 0; i < 3; i++){
            System.out.print("\n" + words[i]);
        }
    }
}
