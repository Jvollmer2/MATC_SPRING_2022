
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jvoll
 */
public class Assingment2 {
    public static void main(String args[]){
        
        Scanner myObj = new Scanner(System.in);
        
        int CookiesPerBag = 40;
        int ServingsPerBag = 10;
        int CaloriesPerServing = 300;
        int CaloriesPerCookie = (CaloriesPerServing/(CookiesPerBag/ServingsPerBag));
        int CookiesAte;
        
        System.out.println("How many cookies did you eat?");
        
        do{
            CookiesAte = myObj.nextInt();
            if(CookiesAte > 40) { 
                System.out.println("There are only 40 cookies in the bag.");
            }
            if(CookiesAte < 0) {
                System.out.println("You can't eat negative cookies.");
            } 
            }while(CookiesAte>40 || CookiesAte<0);
        
        int CaloriesConsumed = CookiesAte*CaloriesPerCookie;
        System.out.println("You have consumed " + CaloriesConsumed + " calories of cookies.");
    
    }    
}
