/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jvoll
 */
public class Restaurant {
   String name;
   boolean vegan;
   boolean vegetarian;
   boolean glutenFree;
   
   public Restaurant(String x, boolean a, boolean b, boolean c){
       name = x;
       vegan = a;
       vegetarian = b;
       glutenFree = c;   
   }
   
}
