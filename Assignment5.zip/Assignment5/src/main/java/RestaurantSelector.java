/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jvoll
 */
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import java.util.Scanner;
import javax.swing.*;

public class RestaurantSelector {
    
    public static void main(String args[]){
        //array of restauraunts
    Scanner myObj = new Scanner(System.in); 
    
    boolean partyGF = false;
    boolean partyVegan = false;
    boolean partyVegetarian = false;
    
    List<Restaurant> restaurantList = new ArrayList<Restaurant>();
    restaurantList.add(new Restaurant("Joes Gourmet Burgers", false, false, false));
    restaurantList.add(new Restaurant("Main Street Pizza Company", false, true, true));
    restaurantList.add(new Restaurant("Corner Cafe", true, true, true));
    restaurantList.add(new Restaurant("Mama's Fine Italian", false, true, false));
    restaurantList.add(new Restaurant("The Chef's Kitchen", true, true, true));
    
    //anybody veg, vegan, GF
    int replyVegetarian = JOptionPane.showConfirmDialog(null, "Is anyone in your party a vegetarian?", "Vegetarian", JOptionPane.YES_NO_OPTION);
    if (replyVegetarian == JOptionPane.YES_OPTION){
        partyVegetarian = true;
    }
    int replyVegan = JOptionPane.showConfirmDialog(null, "Is anyone in your party a vegan?", "Vegan", JOptionPane.YES_NO_OPTION);
    if (replyVegan == JOptionPane.YES_OPTION){
        partyVegan = true;
    }
    int replyGF = JOptionPane.showConfirmDialog(null, "Is anyone in your party a gluten free?", "Gluten Free", JOptionPane.YES_NO_OPTION);
    if (replyGF == JOptionPane.YES_OPTION){
        partyGF = true;
    }
    
    List<Restaurant> restaurantsAvailable = new ArrayList<Restaurant>();
    
    for (int i = 0; i < restaurantList.size(); i++){
        Restaurant x = restaurantList.get(i);
        if (partyGF == true){
            if (x.glutenFree == false){
                continue;
            }
        }
        if (partyVegetarian == true){
            if (x.vegetarian == false){
                continue;
            }
        }
        if (partyVegan == true){
            if (x.vegan == false){
                continue;
            }
        }
        restaurantsAvailable.add(x);
    }
     
    String choices = "Here are your restaurant choices: " + "\n";
    for (int i = 0; i < restaurantsAvailable.size(); i++){
        choices = choices + "   " + restaurantsAvailable.get(i).name + "\n";
    };
    JOptionPane.showMessageDialog(null, choices);
    }
}
