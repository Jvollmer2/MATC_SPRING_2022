/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jvoll
 */

import java.util.Scanner;
import javax.swing.JOptionPane;
import java.math.RoundingMode;
import java.text.DecimalFormat;


public class StockProgram {
    
    private static final DecimalFormat df = new DecimalFormat("0.00");
    
    public static void main(String args[]){
        
        Scanner myObj = new Scanner(System.in);
        
        StockTransaction purchase = new StockTransaction();
        StockTransaction selling = new StockTransaction();
        
        purchase.stockSharesPurchased = Double.parseDouble(JOptionPane.showInputDialog(null, "How many shares were purchased? "));
        purchase.pricePerStock = Double.parseDouble(JOptionPane.showInputDialog(null, "How much did each stock cost? "));
        purchase.commission = Double.parseDouble(JOptionPane.showInputDialog(null, "How much was commision? (as a decimal) "));
        purchase.commissionAsPercentage = purchase.commission * 100;
        
        JOptionPane.showMessageDialog(null, "Joe bought " + purchase.stockSharesPurchased + " stocks for a price of $" + df.format(purchase.pricePerStock) + ", with a commison of " + purchase.commissionAsPercentage + "%.");
        
        selling.stockSharesPurchased = Double.parseDouble(JOptionPane.showInputDialog(null, "How many shares were sold? "));
        selling.pricePerStock = Double.parseDouble(JOptionPane.showInputDialog(null, "How much were the stocks sold for? "));
        selling.commission = Double.parseDouble(JOptionPane.showInputDialog(null, "How much was commision? (as a decimal) "));
        selling.commissionAsPercentage = selling.commission * 100;
        
        JOptionPane.showMessageDialog(null, "Joe sold " + selling.stockSharesPurchased + " stocks for a price of $" + df.format(selling.pricePerStock) + ", with a commison of " + selling.commissionAsPercentage + "%.");
        
        double purchaseCost = purchase.pricePerStock * purchase.stockSharesPurchased;
        double sellingCost = selling.pricePerStock * selling.stockSharesPurchased;
        purchase.commissionCost = purchaseCost * purchase.commission;
        selling.commissionCost = sellingCost * selling.commission;
        double totalPaid = purchaseCost + purchase.commissionCost;
        double totalRecieved = sellingCost - selling.commissionCost;
        double overallProfit = totalRecieved - totalPaid;
        
        JOptionPane.showMessageDialog(null, "Joe paid $" + df.format(purchaseCost) + " for his stock purchase, with a commission of $" + df.format(purchase.commissionCost) + ".");
        JOptionPane.showMessageDialog(null, "Joe sold his stocks for  $" + df.format(sellingCost) + " with a commission of $" + df.format(selling.commissionCost) + ".");
        JOptionPane.showMessageDialog(null, "Including commission, Joe paid a total of $" + df.format(totalPaid) + ". ");
        JOptionPane.showMessageDialog(null, "Including commission, Joe recieved a total of $" + df.format(totalRecieved) + ". ");
        JOptionPane.showMessageDialog(null, "Joe's overall profit was $"  + df.format(overallProfit) + ".");
        
        if (overallProfit < 0){
            JOptionPane.showMessageDialog(null, "Joe lost money :(");
        }
        
        if (overallProfit == 0){
            JOptionPane.showMessageDialog(null, "Joe broke even.");
        }
        
        System.exit(0);
    }
}
